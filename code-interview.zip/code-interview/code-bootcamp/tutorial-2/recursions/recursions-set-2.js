// Recursion CHALLENGE Problem Set Solutions Part 2

// capitalizeWords Solution

// nestedEvenSum Solution


// capitalizeFire Solution

// stringifyNumbers Solution

// collectStrings Solution: Helper Method Recursion Version

// collectStrings Solution: Pure Recursion Version