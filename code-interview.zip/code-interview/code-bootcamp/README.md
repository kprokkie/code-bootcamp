# Code Bootcamp

### Tutorial 0: The Ultimate Interview Bootcamp [JavaScript & LeetCode]

### Tutorial 1: Master the Coding Interview: Data Structures + Algorithms [DONE]

### Tutorial 2: JavaScript Algorithms and Data Structures Masterclass

### Tutorial 3: The Coding Interview Bootcamp: Algorithms + Data Structures

## Install Jest to Test

`> npm i -g jest`

## Run Jest to Test

`> cd excercies`

`> jest fib/test.js`
