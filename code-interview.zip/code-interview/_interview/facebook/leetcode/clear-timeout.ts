// const t1 = setTimeout(() => {
//     console.log('I m in.');
// }, 1000);

// clearTimeout(t1);

// or

function callback1() {
    console.log('call 1');
}

function callback2() {
    console.log('call 2');
}

let allTimeout = [];

const t11 = setTimeout(callback1, 1000);
const t22 = setTimeout(callback2, 2000);

// allTimeout.forEach((t) => clearTimeout(t));

// function setTimeout(fn, delay) {
//     let t = this.setTimeout(fn, delay);
//     allTimeout.push(t);
//     return t;
// }

// function clearAllTimeout() {
//     allTimeout.forEach((t) => clearTimeout(t));
//     allTimeout = [];
// }

// clearAllTimeout();

// ------------------------------------------------

const originalSetTimeout = this.setTimeout

const originalClearTimeout = this.clearTimeout


const map = {}


this.setTimeout = function (callback, delay) {
    console.log('setting time out...')
    const id = originalSetTimeout(callback, delay)
    map[id] = callback
    return id
}


this.clearTimeout = function (id) {
    if (map.hasOwnProperty(id)) {
        originalClearTimeout(id)
        delete map[id]
        console.log('cleared timeout...', map, id)
    }
}


this.clearAllTimeout = function () {
    Object.keys(map).forEach((id) => clearTimeout(+id));
}

this.clearAllTimeout();

