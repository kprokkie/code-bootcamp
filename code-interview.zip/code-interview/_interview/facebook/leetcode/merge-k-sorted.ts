https://leetcode.com/problems/merge-k-sorted-lists/discuss/327596/JavaScript-3-solutions
