/**
 * @param {string} S
 * @return {string}
 */
var removeDuplicates = function (S) {
    let stack = [];

    for (let char of S) {
        if (!stack.length || stack[stack.length - 1] !== char)
            stack.push(char);
        else 
            stack.pop();
    }

    return stack.join('');
};


console.log(removeDuplicates('abbaca'));