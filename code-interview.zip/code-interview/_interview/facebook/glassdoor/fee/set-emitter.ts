https://gist.github.com/robinpokorny/d743ed9e0bc5214f79076a16c8e44a8f

export default () => {
    const subscribers = new Set()

    const sub = (fn) => {
        subscribers.add(fn)

        return () => subscribers.delete(fn)
    }

    const pub = (data) => subscribers.forEach((fn) => fn(data))

    return Object.freeze({ pub, sub })
}

import pubsub from './pubsub'

// Create a new PubSub
const events = pubsub()

// Register first subscriber
// Save the unsubscribe callback
const unSubOne = events.sub((a) => console.log('one: ' + a))

const two = (a) => console.log('two: ' + a)

// Register second subscriber
const unSubTwo = events.sub(two)
// Subscriber can be registred only once, the following has no effect
events.sub(two)

// Dispatch a string
// `two` is called just once
events.pub('foo')
// "one: foo"
// "two: foo"

// Deregister a subscriber
// Returns true if the function has been removed successfully
unSubOne() // true

// Dispatch a string
// `one` is not called
events.pub('bar')
// "two: bar"