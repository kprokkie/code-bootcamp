// Given a string and a style array render HTML pretty much like a rich text editor.
// For example: 'Hello, world', [[0, 2, 'i'], [4, 9, 'b'], [7, 10, 'u']]
// Output: '<i>Hel</i>l<b>o, w<u>orl</u></b><u>d</u> something like that. 

const str = 'Hello, world'
const style = [[0, 2, 'i'], [4, 9, 'b'], [7, 10, 'u']];

function renderHTML(str, style) {

}

console.log(renderHTML(str, style));   