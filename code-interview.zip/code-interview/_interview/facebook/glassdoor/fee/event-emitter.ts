class EventEmitter {
    listeners = {};  // key-value pair
    
    addListener(eventName, fn) {}
    on(eventName, fn) {}
    
    removeListener(eventName, fn) {}
    off(eventName, fn) {}
    
    once(eventName, fn) {}
    
    emit(eventName, ...args) { }
    
    listenerCount(eventName) {}
    
    rawListeners(eventName) {}
  }
// -------------------------------------
const myEmitter = new EventEmitter();

function c1() {
   console.log('an event occurred!');
}

function c2() {
   console.log('yet another event occurred!');
}

myEmitter.on('eventOne', c1); // Register for eventOne
myEmitter.on('eventOne', c2); // Register for eventOne

myEmitter.emit('eventOne');
// ---------------------------------------

myEmitter.once('eventOnce', () => console.log('eventOnce once fired')); 
myEmitter.emit('eventOne');

// ------------------------------------------

myEmitter.on('status', (code, msg)=> console.log(`Got ${code} and ${msg}`));
myEmitter.emit('status', 200, 'ok');

// -------------------------------------------
myEmitter.off('eventOne', c1);

myEmitter.emit('eventOne');  // noop

// -------------------------------------

console.log(myEmitter.listenerCount('eventOne'));
console.log(myEmitter.rawListeners('eventOne'));

// https://www.freecodecamp.org/news/how-to-code-your-own-event-emitter-in-node-js-a-step-by-step-guide-e13b7e7908e1/
