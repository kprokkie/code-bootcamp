 {
    class EventEmitter {

        events;

        constructor() {
            this.events = new Map();
        }

        subscribe(eventName, callbackFn) {
            this.events.set(eventName, callbackFn);
            return {
                unsubscribe: () => this.events.delete(eventName)
            }
        }

        emit(eventName, ...params) {
            if (this.events.has(eventName)) {
                this.events.get(eventName).apply(null, params);
            }
        }

    }

    const emitter = new EventEmitter();

    const callback1 = (data) => {
        console.log(`Hello, I am in home with ${data.user}.`);
    }

    const callback2 = (data) => {
        console.log(`Hello, I am in plane with ${data.user}.`);
    }

    const sub1 = emitter.subscribe('status', callback1);
    const sub2 = emitter.subscribe('status', callback2);
    const sub3 = emitter.subscribe('action', callback1);

    emitter.emit('status', { user: 'rokkie' });
    emitter.emit('action', { user: 'vikas' });

    console.log('unsubscribe --------------');
    sub1.unsubscribe();

    emitter.emit('status', { user: 'rokkie' });
    emitter.emit('action', { user: 'vikas' });


}