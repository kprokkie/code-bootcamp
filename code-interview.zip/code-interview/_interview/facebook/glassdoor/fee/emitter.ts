{
    // EventEmitter that has three methods: subscribe/on, emit, and release/remove
    // events - a super-basic Javascript (publish subscribe) pattern
    class EventEmitter {

        events;

        constructor() {
            this.events = {};
        }

        // subscribe or on 
        // on("eventName", callbackFn) 
        // function that takes an eventName and a callbackFn, should save the callbackFn to be called when the event with eventName is emitted.
        on(eventName, callbackFn) {
            // if (!this.events[eventName])
            //     this.events[eventName] = [];
            this.events[eventName] = this.events[eventName] || [];
            this.events[eventName].push(callbackFn);
        }

        // emit
        // emit("eventName", data)
        // function that takes an eventName and data object, should call the callbackFns associated with that event and pass them the data object.
        emit(eventName, eventData) {
            console.log(eventData);
            if (!this.events[eventName]) return;
            // this.events[eventName].forEach(fn => fn(eventData));
            this.events[eventName].forEach(fn => fn.call(null, eventData));
            // this.events[eventName].forEach(fn => fn.apply(null, eventData));

        }

        // release or remove
        // remove("eventName", callbackFn)
        // a function that takes eventName and callbackFn, should remove that callbackFn from the event.
        remove(eventName, callbackFn) {
            const idx = this.events[eventName].indexOf(callbackFn);
            if (idx === -1) return;
            this.events[eventName].splice(idx, 1);
        }

    }

    const emitter = new EventEmitter();

    const callback1 = (data) => {
        console.log(`Hello, I am in home with ${data.user}.`);
    }

    const callback2 = (data) => {
        console.log(`Hello, I am in plane with ${data.user}.`);
    }

    emitter.on('status', callback1);
    // emitter.on('status', callback1);
    emitter.on('status', callback2);
    emitter.on('action', callback1);

    emitter.emit('status', { user: 'rokkie' });
    emitter.emit('action', { user: 'vikas' });

    console.log('remove --------------');
    emitter.remove('status', callback1);

    emitter.emit('status', { user: 'nitin' });

}
{
    var events = (function () {

        var events = {};

        function on(eventName, fn) {
            events[eventName] = events[eventName] || [];
            events[eventName].push(fn);
        }

        function off(eventName, fn) {
            if (events[eventName]) {
                for (var i = 0; i < events[eventName].length; i++) {
                    if (events[eventName][i] === fn) {
                        events[eventName].splice(i, 1);
                        break;
                    }
                }
            }
        }

        function emit(eventName, data) {
            if (events[eventName]) {
                events[eventName].forEach(function (fn) {
                    fn(data);
                });
            }
        }

        return {
            on: on,
            off: off,
            emit: emit
        };

    })();
}