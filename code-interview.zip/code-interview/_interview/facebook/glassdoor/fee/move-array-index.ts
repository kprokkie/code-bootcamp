{
    const arr = [10, 30, 40, 20, 60, 50, 90];
    // const idx = [0, 3, 1, 6, 2, 4, 5];
    const idx = [1, 0, 3, 2, 5, 4, 6];

    function moveArrayIndex(arr, idx) {

        for (let i = 0; i < arr.length; i++) {
            let counter = 0;
            while (idx[i] !== i) {

                counter++;

                let targetV = arr[idx[i]]; // 20
                let targetI = idx[idx[i]]; // 2

                arr[idx[i]] = arr[i]; // 10 [10, 10, 40, 20]
                idx[idx[i]] = idx[i]; //  3 [1, 1, 2, 3]

                arr[i] = targetV; // 30 [30, 10, 40, 20]
                idx[i] = targetI; // 0 [0, 1, 2, 3]

                console.log(counter, i, idx[i], arr[i]);
            }
        }
        return [arr, idx];
    }

    console.log(moveArrayIndex([...arr], [...idx]));


}