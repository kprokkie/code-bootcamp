// Observables are lazy; we don’t invoke the function yet just saving a reference.
class Observable {

    constructor(functionThatThrowsValues) {
        this._functionThatThrowsValues = functionThatThrowsValues;
    }

    subscribe(observer) {
        return this._functionThatThrowsValues(observer);
    }

    static fromArray(array) {
        return new Observable(observer => {
            array.forEach(val => observer.next(val));
            observer.complete();
        });
    }

}

let array$ = Observable.fromArray([1, 2, 3]);
array$.subscribe({
    next(val) { console.log(val) },
    error(e) { console.log(e) },
    complete() { console.log('complete') }
});