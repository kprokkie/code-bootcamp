{
    const matrix = [
        [1, 2, 3, 4],
        [5, 6, 7, 8],
        [9, 10, 11, 12],
        [13, 14, 15, 16]
    ];

    function dfsIterative(matrix, i, j, row, col, visited, result) {

        let stack = [];
        stack.push([i, j]);

        while (stack.length) {

            let idx = stack.pop();
            let i = idx[0], j = idx[1];

            if (i < 0 || j < 0 || i >= row || j >= col || visited[i + '_' + j]) continue;

            visited[i + '_' + j] = true;
            result.push(matrix[i][j]);

            stack.push([i, j - 1]); // down
            stack.push([i, j + 1]); // up
            stack.push([i - 1, j]); // left
            stack.push([i + 1, j]); // right
           
        }
    }

    function dfsRecursive(matrix, i, j, row, col, visited, result) {

        if (i < 0 || j < 0 || i >= row || j >= col || visited[i + '_' + j]) return;

        visited[i + '_' + j] = true;
        result.push(matrix[i][j]);

        dfsRecursive(matrix, i + 1, j, row, col, visited, result); // right
        dfsRecursive(matrix, i - 1, j, row, col, visited, result); // left
        dfsRecursive(matrix, i, j - 1, row, col, visited, result); // down
        dfsRecursive(matrix, i, j + 1, row, col, visited, result); // up

    }

    function dfsTraversal() {

        let row = matrix.length;
        let col = matrix[0].length;

        // visited 2d array 
        // const visited = Array(row).fill(new Array(col).fill(false));
        let visitedHash = {};
        const result = [];

        // dfsRecursive(matrix, 0, 0, row, col, visitedHash, result);
        dfsIterative(matrix, 0, 0, row, col, visitedHash, result);
        console.log(result);
    }

    dfsTraversal();


}