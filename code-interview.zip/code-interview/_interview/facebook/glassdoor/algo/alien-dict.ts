{
    function alienDict(words, order) {

        let aCode = 'a'.charCodeAt(0);

        let index = [];
        for (let i = 0; i < order.length; i++) {
            index[order.charCodeAt(i) - aCode] = i;
        }

        // console.log(index, index.length, order.length);

        for (let j = 0; j < words.length - 1; j++) {
            let word1 = words[j], word2 = words[j + 1];

            let minLength = Math.min(word1.length, word2.length);
            for (let k = 0; k < minLength; k++) {
                if (word1.charAt(k) !== word2.charAt(k)) {
                    if (index[word1.charCodeAt(k) - aCode] > index[word2.charCodeAt(k) - aCode])
                        // console.log(word1.charAt(k), word2.charAt(k));
                        return false;
                    else break;
                }
            }

            if (word1.length > word2.length)
                return false;
        }

        return true;
    }

    let bool1 = alienDict(["hello", "leetcode"], 'hlabcdefgijkmnopqrstuvwxyz');
    console.log(bool1);

    let bool2 = alienDict(["apple", "app"], "abcdefghijklmnopqrstuvwxyz");
    console.log(bool2);

    let bool3 = alienDict(["kuvp", "q"], "ngxlkthsjuoqcpavbfdermiywz");
    console.log(bool3);
}
{
    var isAlienSorted = function (words, order) {
        for (let i = 1; i < words.length; i++) {
            const a = words[i - 1]
            const b = words[i]
            const maxLen = Math.max(a.length, b.length)
            for (let j = 0; j < maxLen; j++) {
                const indexA = order.indexOf(a[j])
                const indexB = order.indexOf(b[j])
                console.log(indexA, b[j]);
                if (indexA > indexB) {
                    return false
                } else if (indexA < indexB) {
                    j = maxLen
                }
            }
        }
        return true
    };

    // let bool1 = isAlienSorted(["hello", "leetcode"], 'hlabcdefgijkmnopqrstuvwxyz');
    // console.log(bool1);

    let bool2 = isAlienSorted(["apple", "app"], "abcdefghijklmnopqrstuvwxyz");
    console.log(bool2);

    // let bool3 = isAlienSorted(["kuvp", "q"], "ngxlkthsjuoqcpavbfdermiywz");
    // console.log(bool3);
}