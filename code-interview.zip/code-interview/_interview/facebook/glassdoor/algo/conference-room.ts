{
    const intervals = [[0, 30], [5, 10], [15, 20]];
    // const intervals = [[0, 60], [20, 30], [40, 50]];

    function roomRequired(intervals) {

        let base = intervals[0];
        let count = 1;
        for (let i = 1; i < intervals.length; i++) {
            if (base[1] < intervals[i][0]) {
                base = intervals[i];
            } else {
                count++;
            }
        }

        return count;

    }

    console.log(roomRequired(intervals));

}