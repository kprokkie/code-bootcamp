{

    const version = [false, false, false, false, true, true, true, true, true, true];

    function isBadVersion(idx) {
        return version[idx];
    }

    function firstBadVersion(n) {
        let left = 0;
        let right = n - 1;

        while (left < right) {

            let mid = Math.floor((left + right) / 2);
            console.log(left, mid, right);
            if (isBadVersion(mid)) right = mid;
            else left = mid + 1;
        }

        return left + 1;
    }

    console.log(firstBadVersion(version.length));


}