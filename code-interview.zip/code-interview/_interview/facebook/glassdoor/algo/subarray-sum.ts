{
    const arr = [1, 4, 20, 3, 10, 5]; // Non -ve
    const arr1 = [10, 2, -2, -20, 10];
    const target = 33;

    function subArraySum(arr, target) {

        for (let i = 0; i < arr.length; i++) {
            console.log('start');
            let sum = arr[i];
            for (let j = i + 1; j < arr.length; j++) {
                console.log(sum);
                if (sum == target) {
                    console.log('match at: ', i, j - 1);
                    return;
                }
                if (sum > target) break;
                sum += arr[j];
            }
        }

    }
    function subArraySumO(arr, target) {
        let sum = arr[0];
        let start = 0;

        for (let i = 1; i < arr.length; i++) {
            console.log(sum, target);

            while (sum > target) {
                console.log('down');
                sum -= arr[start++];
            }

            if (sum < target) {
                sum += arr[i];
            }

            if (sum === target) {
                console.log('match', start, i - 1);
            }
        }
    }

    function negArraySum(arr, target) {
        let map = new Map();
        let sum = 0;

        for (let i = 0; i < arr.length; i++) {
            console.log('------', sum);
            sum += arr[i];
            if (sum === target) {
                console.log('match');
            }

            if (map.has(sum - target)) {

                console.log('map has', map.get(sum - target) + 1, i);
            }

            map.set(sum, i);




        }


    }

    //subArraySum(arr, target);
    // subArraySumO(arr, target);
    // subArraySumO(arr, target);
    negArraySum(arr1, -10);

}