{
    const root = {
        val: 1,
        right: { val: 3, right: null, left: null },
        left:
        {
            val: 2,
            right: { val: 5, right: null, left: null },
            left: { val: 4, right: null, left: null }
        }
    };

    function maxDepth(node) {
        if (!node) return 0;
        let left = maxDepth(node.left);
        let right = maxDepth(node.right);
        return Math.max(left, right) + 1;
    }

    function minDepth(node) {
        if (!node) return 0;
        let left = minDepth(node.left);
        let right = minDepth(node.right);
        return Math.min(left, right) + 1;
    }

    console.log(maxDepth(root));
    console.log(minDepth(root));
}