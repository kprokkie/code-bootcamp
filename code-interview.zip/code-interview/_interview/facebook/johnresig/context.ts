function katana() {
    this.isSharp = true;
}
katana();
console.log(isSharp === true, "A global object now exists with that name and value.");

var shuriken = {
    toss: function () {
        this.isSharp = true;
    }
};
shuriken.toss();
console.log(shuriken.isSharp === true, "When it's an object property, the value is set within the object.");

var object = {};
function fn() {
    return this;
}
assert(fn() == this, "The context is the global object.");
assert(fn.call(object) == object, "The context is changed to a specific object.");