
var ninja = {
    yell: function (n) {
        return n > 0 ? ninja.yell(n - 1) + "a" : "hiy";
    }
};

var ninja = {
    yell: function yell(n) {
        return n > 0 ? yell(n - 1) + "a" : "hiy";
    }
};

// arguments.callee is the function itself
var ninja = {
    yell: function (n) {
        return n > 0 ? arguments.callee(n - 1) + "a" : "hiy";
    }
}; 

//--------------------------------------------------

function User(first, last){
    if ( !(this instanceof User) )
      return new User(first, last);
    
    this.name = first + " " + last;
  }
  
  var name = "Resig";
  var user = User("John", name);
  
  assert( user, "This was defined correctly, even if it was by mistake." );
  assert( name == "Resig", "The right name was maintained." );

  function User(first, last){
    if ( !(this instanceof arguments.callee) )
      return new User(first, last);
    
    this.name = first + " " + last;
  }
  
  var name = "Resig";
  var user = User("John", name);
  
  assert( user, "This was defined correctly, even if it was by mistake." );
  assert( name == "Resig", "The right name was maintained." );