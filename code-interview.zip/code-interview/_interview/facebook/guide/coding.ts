function isPrime(n) {
    let counter = 0;
    if (n < 2) return false;

    console.log(Math.sqrt(n), Math.ceil(Math.sqrt(n)));
    for (let i = 2; i < Math.ceil(Math.sqrt(n)) + 1; i++) {
        console.log(++counter);
        if (n % i === 0) return false;
    }

    return true;
}

// console.log(isPrime(0), false);
// console.log(isPrime(1), false);
// console.log(isPrime(9), false);
console.log(isPrime(17), true);
console.log(isPrime(25), false);
console.log(isPrime(73), true);
// console.log(isPrime(10000000000000), false);

console.log('factorial(0)');

// function factorial (n) {
//     if (n < 2) return 1;
//     return n * factorial(n-1);
// }

function factorial(n) {

    let map = new Map();

    function helper(n) {
        if (n == 0) return 1;
        return n * helper(n - 1);
    }

    return helper(n);

    // if (map.has(n)) return map.get(n);
    // else  {
    //     let result= helper();
    // }
}

console.log(factorial(0));
console.log(factorial(1));
console.log(factorial(2));
console.log(factorial(3));
console.log(factorial(4));
console.log(factorial(5));
console.log(factorial(10));

console.log('fibo');

// 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144

// function fibo(n) {
    
//     function helper (n) {
//         console.log(n);
//         if (n == 0 || n == 1) return n;
//         return helper(n - 1) + helper(n - 2);
//     }
//     return helper(n);

// }

function fibo(n) {
    
   let arr = [];
   arr[0] = 0;
   arr[1] = 1;

   for (let i = 2; i <= n; i++) {
       console.log(n);
       arr[i] = arr[i-1] + arr[i-2];
   }

   return arr[n];

}

// console.log(fibo(0));
// console.log(fibo(1));
// console.log(fibo(2));
// console.log(fibo(3));
// console.log(fibo(5));
// console.log(fibo(10));
// console.log(fibo(15));
console.log(fibo(20));