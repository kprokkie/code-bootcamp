{

    const node1 = {
        value: 1,
        left: null,
        right: null
    }

    const node2 = {
        value: 1,
        left: {
            value: 2,
            left: {
                value: 4,
                left: null,
                right: null
            },
            right: {
                value: 5,
                left: null,
                right: null
            }
        },
        right: {
            value: 3,
            left: null,
            right: {
                value: 6,
                left: null,
                right: null
            }
        }
    }

    function pathToLeaf(root) {

        if (!root) return [];

        let result = [];

        function helper(node, [...path]) {

            path.push(node.value);
            if (!node.left && !node.right) result.push(path);

            if (node.left) helper(node.left, path);
            if (node.right) helper(node.right, path);

        }

        helper(root, []);
        return result;

    }

    console.log(pathToLeaf(node2));
}