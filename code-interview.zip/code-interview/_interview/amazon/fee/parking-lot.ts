// enum VehicleType {
//     Car, Truck, Bike
// }

// enum ParkingSpotType {
//     Compact, Large, Bike
// }

// class Vehicle {
//     private 
// }