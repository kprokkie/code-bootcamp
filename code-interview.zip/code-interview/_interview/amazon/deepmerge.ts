function deepmerge(a, b) {
    //
    if (!a && !b) return undefined;
    if (!a) return b;
    if (!b) return a;
    
    if (typeof a !== 'Object' ||  typeof b !== 'Object') return b;
    
    
    let target = {}; 
    
    function mergeObj (obj) {
        for (let prop in obj) {
            //{ a: { g: 'h' } }
            if (typeof obj[prop] === 'Object')
                target[prop] = deepmerge(target[prop], obj[prop]);
                // target: {a: {e: f}}
            else 
                target[prop] = obj[prop];
        }
    }
    function mergeArr() {
        //
    }
    function mergeClass() {
        //
    }
    //...
    // target: {a: {e: f, g: h}
    
    // 
    for (let i = 0; i < this.arguments; i++) {
        // { a: { e: 'f' } } // { e: 'f' }
        // { a: { g: 'h' } } // { g: 'h' }
        mergeObj(arguments[i]);
    }
    
    return target;
    
    
}

deepmerge(undefined, undefined) --> undefined
deepmerge(5, undefined) --> 5

deepmerge([], [])
deepmerge(new Map(), new Map())
deepmerge(new MyThing(), new MyThing())

deepmerge('bar', 'foo') --> 'foo'
deepmerge('foo', 'bar') --> 'bar'
deepmerge(5, 'foo') --> 'foo'
deepmerge('foo', 5) --> 5
deepmerge({a: 'b'}, 5) --> 5
deepmerge('foo', {a: 'b'}) --> {a: 'b'}

deepmerge({ a: 'b' }, { c: 'd' }) --> { a: 'b', c: 'd' }
deepmerge({ a: { e: 'f' } }, { a: { g: 'h' } }) --> { a: { e: 'f', g: 'h' } }







