/**
 * For the in-order traversal complexity problem, was the interviewer looking for below solution ?

iterative inorder with stack - https://www.geeksforgeeks.org/inorder-tree-traversal-without-recursion/
iterative inorder without stack - https://www.geeksforgeeks.org/inorder-tree-traversal-without-recursion-and-without-stack/
 */