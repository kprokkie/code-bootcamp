import * as React from 'react';
import { tableAPI } from '../api';

const PropTypes = {};

export class Table extends React.Component {
    
    createTable(data) {
        const table = document.createElement('table');
        
        const keys = Object.keys(data[0]); // [name, age]
        
        for (let i = 0; i < data.length; i++) {
            const tr = document.createElement('tr');
            
            for (let j = 0; j < keys.length; j++ ) {
                const td = document.createElement('td');
                td.textContent = data[i][keys[j]];
                
                tr.appendChild(td);
            }
            
            table.append(tr);
        }
        return table;
    }
    
    async callData() {
        const {data} = await axios.get(url)
    }
    
    // IN THE PARENT COMPONENT
    onNext() {
        // api  tableAPI({pageIndex = 2, noOfRequired = 50})
        
        
        
        
        this.setState({
            products: data
        })
    }
    
    render() {
        return (
            <div>
                <button onClick={this.props.onNext}>Next</button>
                <button onClick={}>Prev</button>
            </div>
            <table>
                {this.props.data.forEach((data) =>  {
                    return (<tr>
                        {this.props.keys.forEach(key => {
                            return (<td>{data[key]}</td>)
                        })}
                    </tr>);
                })}
            </table>
            );
    }
}


data = [
        {deploy: 'Ankit',
        age: 23},
        {name: 'Ankit1',
        age: 13},
        {name: 'Ankit1',
        age: 33},
    ]'
    
dataHeader = {
    name: 'Regional'
}

// Describe API here
http://api/names
how many ? 5, 10, 50, 100
pagination? 1, 2,3 , 100

data :  {
    from: 101,
    to: 200,
    result: [],
    totalElements: 1000
}

data: {
    pageIndex: 2,
    totalrequierd: 100,
}