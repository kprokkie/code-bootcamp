<html>
  <head>
    <link rel="stylesheet" type="text/css" href="styles.css">
  </head>
  <body>
    <div id="turn">
      <!-- Insert turn indicator here -->
    </div>
    <div id="container">
      <!-- Insert game board here -->
      <div class="row">
        <div class="col"></div>
        <div class="col"></div>
       <div class="col"></div>
      </div>
      <div class="row">
        <div class="col"></div>
        <div class="col"></div>
       <div class="col"></div>
      </div>
      <div class="row">
        <div class="col"></div>
        <div class="col"></div>
       <div class="col"></div>
      </div>
    </div>

    <button id="reset">Replay</button>
    <script src="script.js"></script>
  </body>
</html>

let couter = 1;

const playerTurn = document.querySelector('#turn');
playerTurn.innerHTML = 'X Turn';

const container = document.getElementById('container');
container.addEventListener('click', clickHandler);

function clickHandler (e) {
  couter++;
  const div = e.target;
  div.innerHTML = couter % 2 === 0 ? 'X': '0';
  div.classList.add('zero');
  if (e.target) {
    console.log(e.target);
  }

  updatePlayerTurn();

}

function updatePlayerTurn() { 
  if (couter % 2 === 0) playerTurn.innerHTML = 'Y Turn';
  else playerTurn.innerHTML = 'X Turn';
  if (couter === 10) playerTurn.innerHTML = 'Game Over';
}

const reset = document.getElementById('reset');
reset.addEventListener('click', function() {
  counter = 1;
  updatePlayerTurn();
  const columns = container.querySelectorAll('.col');
  columns.forEach((col) => {
    col.innerHTML = '';
  })
});

#container {
}

#container .row {
  display: flex;
}

#container .row .col {
  border: 1px solid #ccc;
  height: 100px;
  width: 100px;
  cursor: pointer;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 2rem;
}

#container .row .col:hover {
  background: #eee;
}





