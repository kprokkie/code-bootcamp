const arr = [5, 5, 10, 40, 50, 35];

const arr2 = [-5, 5, -10, -40, 50, 35];


function maxSum(arr) {
    let inc = arr[0]
    let exc = 0;

    for (let i = 1; i < arr.length; i++) {
        // let excTemp = inc > exc ? inc : exc;
        let excTemp = Math.max(inc, exc);

        inc = exc + arr[i];
        exc = excTemp;
    }

    // return inc > exc ? inc : exc;
    return Math.max(inc, exc);
}

console.log(maxSum(arr));

console.log(maxSum(arr2));