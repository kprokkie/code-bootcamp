const arr = [1, 2, 3, 4, 5];


function arraymove(arr, fromIndex, toIndex) {
    var element = arr[fromIndex]; // caprure the elememt
    console.log(element);
    arr.splice(fromIndex, 1); // remove 1 element fromIndex
    console.log(arr);
    arr.splice(toIndex, 0, element); // insert element toIndex
    console.log(arr);
}

arraymove(arr, 0, 4);