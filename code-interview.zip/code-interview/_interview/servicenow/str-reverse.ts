const str = 'abcdefghi';

function revStr1(str) {
    let res = '';

    for (let char of str) {
        res = char + res;
    }

    return res;
}

console.log(revStr1(str));