const arr1 = [2, 5, 6, 7, 9];
const arr2 = [4, 5, 8, 10];

function mergeSortedArray(s, t) {
    let mArr = [];

    let i = 0;
    let j = 0;

    while (i < s.length && j < t.length) {
        if (s[i] === t[j]) {
            mArr.push(s[i]);
            i++; j++;
        }

        if (s[i] < t[j]) {
            mArr.push(s[i]);
            i++;
        } else {
            mArr.push(t[j]);
            j++;
        }
    }

    while (i < s.length) {
        mArr.push(s[i]);
        i++;
    }

    while (j < t.length) {
        mArr.push(t[j]);
        j++;
    }
    console.log(mArr.length);
    return JSON.stringify(mArr);

}

console.log(mergeSortedArray(arr1, arr2));