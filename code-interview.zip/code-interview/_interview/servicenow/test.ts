/**
 * Find and remove all consecutive duplicates from a string
 * function removeDuplicates(inputString)
 * Example: 122333444411234
 * Result: 12341234
 */

function removeDuplicates(str) {

    if (!str.length) return '';

    let resultStr = str[0]; // 1

    // 122333444411234
    for (let i = 1; i < str.length; i++) {
        if (str[i] !== str[i-1]) resultStr += str[i];
    }

    // resultStr 1234
    return resultStr;

}

console.log(removeDuplicates('122333444411234'));