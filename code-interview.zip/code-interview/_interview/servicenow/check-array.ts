Array.prototype.checkArray = function () {
    console.log(this);
    console.log(Object.prototype.toString.call(this));
    // return Object.prototype.toString.call(this) == '[Object Array]';
    return this instanceof Array;
}

console.log([1, 2, 3, 4].checkArray());
console.log('asd'.checkArray());