const arr = [1, 5, 7, -1, 5];
const sum = 6;

function countPairs(arr, sum) {

    let hash = {};
    for (let i = 0; i < arr.length; i++) {
        hash[arr[i]] = hash[arr[i]] ? ++hash[arr[i]] : 1;
    }

    let count = 0;

    for (let key in hash) {
        // console.log(key);
        if (hash[sum - +key]) {
            // console.log(sum - +key);
            count++;
        }
        if (sum - +key === +key)
            count--;
    }

    // console.log(hash);
    return count / 2;

}

console.log(countPairs(arr, sum));