model= {
    "name": "checkbox",
    "value": true,
    "disabled": false,
    "label": "Ship your item",
    "description": "Provide the package weight and dimensions to calculate the cost, or enter a fixed cost.",
    "options": [
      {
        "value": true
        "description": "checked description",
      },
      {
        "value": false
        "description": "unchecked description",
      }
    ]
  }
  
  1)  build a checkbox component. 
  
    <check-box id="checkbox1" [data]="model" [emiiter]="call($event)" ></check-box>
  
  @Component({
    selector: 'check-box',
    templateUrl: ''
  })
  
  export class CheckBox {
  
    @input() data;
    @Output() emitter;
    
    onrender() {
      this.checkbox = this.getel('#checkbox1');
    }
    
    change() {
      // checked state, name , value
      const ischecked =  this.checkbox.is(':checked');
      const name =  this.checkbox.name;
      const value =  this.checkbox.value;
      this.emitter.emit('emitvalue', ischecked, name ,value );
    }
    // if arg is present set checked state else retrive shecked state
    val(arguments) {
      if (arguments.length) {
       this.checkbox.value = arguments[0];
       // this.checkbox.attr('checked', arguments);
      } else this.checkbox.is(':checked');
      this.checkbox.setStstateDirty();
    }    
  
  }
  
  
  <input type="data.name" name="data.name" [checked]="(data.model.value === data.model.options[0].value)" [disabled]="data.disabled" (change)="change()" >
   :before <lable>{{data.label}}</lable> :after
  
  
  [input="name=checkckbox"] + label:before {
    content: '';
    background: 'imageurl'
    width: 16px;
    height: 20px;
    display: inline-block;
  
  }
  
  
  
  
  