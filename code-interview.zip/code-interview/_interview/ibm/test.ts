// you can write to stdout for debugging purposes, e.g.
// console.log('this is a debug message');

function solution(A) {
    // write your code in JavaScript (Node.js 8.9.4)

    A = A.sort();
    let result = 1;

    for (let i = 0; i < A.length; i++) {
        if (A[i] > result) {
            return result;
        }
        if (A[i] === result) {
            result++;
        } 
    }
    return result++;
}

const A = [1, 3, 6, 4, 1, 2];
const B = [1,2,3];
const C = [-1, -3];
const D = [1, 3, 6, -4, -1, 2];
console.log(solution(A));
console.log(solution(B));
console.log(solution(C));
console.log(solution(D));