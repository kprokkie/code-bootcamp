// Given a Range N, return a random sample of size K elements
// without duplicates.
// ie. Take a random sample from Range N, without replacement.
// Example: N = 10, k = 3
// Result: {1,5,7} each element in K_i is: 1-10
// K <= N
// 1 < N < 100000

function returnRandom(n, k) {
  
    let set = new Set(); // {4, 7
    
    while (set.size < k) { // 1 // 2
       let random = Math.floor(Math.random() * n); // 4 // 7 // 4
       set.add(random);
    }
    
    return set; 
    
  }
  
  /*
  // Given a Range N, return a random sample of size K elements
// without duplicates.
// ie. Take a random sample from Range N, without replacement.
// Example: N = 10, k = 3
// Result: {1,5,7} each element in K_i is: 1-10
// K <= N
// 1 < N < 100000

function returnRandom(n, k) {
  
  let set = new Set(); // {4, 7
  
  while (set.size < k) { // 1 // 2
     let random = Math.floor(Math.random() * n); // 4 // 7 // 4
     set.add(random);
  }
  
  return set; 
  
}

// Merge Intervals:
// Given a collection of intervals, merge any overlapping intervals.
// An interval is defined as the range of numbers between a start and end
//
// The beginning of the interval is less than the end of the interval.
//
// ?????
//
// Example: [(1,4),(2,5),(7,9)]
// Result: [(1,5), (7,9)]
//
// [(1,4),(2,7),(3,9)]
// [ (1, 7), (3, 9)]

function mergeIntervals(intervals) {
  
    if (!intervals.length) return [];

    let result = []; // O(n)
    let baseI = intervals[0]; // (1,4)
  
    for (let i = 1; i < intervals.length; i++) { // O(n)
         // (1,3) // (4,5)
        if (baseI[1] >= intervals[i][0]) {
          baseI = [baseI[0],Math.max(baseI[1], intervals[i][1]) ];
        } else {
          result.push(baseI); // O(1)
          baseI = intervals[i];
        }
    }
    result.push(baseI);
  
    return result;

}

console.log(mergeIntervals([[1,4],[2,5],[7,9]]));


class Node {
  constructor(value) {
    this.value = value;
    this.next = null;
  }
}

// 1- > 2 -> 3 -> 4

class LinkedList {
  
  constuctor() {
    this.head = null;
  }
    
  addNode(val) {
    const node = new Node(val);
    
    let currNode = this.head;
    while (currNode.next) {
      currNode = currNode.next;
    }
    
    currNode.next = node;
  }
  
  checkCycle() {
    let hash = {};
    
    
    
  }
 
}










