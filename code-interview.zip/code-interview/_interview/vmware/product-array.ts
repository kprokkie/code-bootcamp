function productArray(arr) {
    let l = [];
    let r = [];

    l[0] = 1;
    for (let i = 1; i < arr.length; i++) {
        l[i] = l[i - 1] * arr[i - 1];
    }
    console.log(l);

    r[arr.length - 1] = 1;
    for (let i = arr.length - 2; i >= 0; i--) {
        r[i] = r[i + 1] * arr[i + 1];
    }
    console.log(r);

    let answer = [];
    for (let k = 0; k < arr.length; k++) {
        answer[k] = l[k] * r[k];
    }

    return answer;
}

function productArray2(arr) {
    let l = [];
    let r = [];

    l[0] = 1;
    for (let i = 1; i < arr.length; i++) {
        l[i] = l[i - 1] * arr[i - 1];
    }

    r[arr.length - 1] = 1;
    for (let i = arr.length - 2; i >= 0; i--) {
        r[i] = r[i + 1] * arr[i + 1];
    }

    let answer = [];
    for (let k = 0; k < arr.length; k++) {
        answer[k] = l[k] * r[k];
    }

    return answer;
}

const arr = [1,2,3,4,5];
console.log(productArray(arr));
console.log(productArray2(arr));