var add = (function () {
    var counter = 0;
    return function () {counter += 1; return counter}
})();

add();
add();
add();

  // OR

  // Explaination of closure 
/* 1 */        function foo()
/* 2 */ {
/* 3 */             var b = 1;
/* 4 */             function inner() {
/* 5 */                 return b;
        /* 6 */
}
/* 7 */             return inner;
    /* 8 */
}
/* 9 */         var get_func_inner = foo();

/* 10 */         console.log(get_func_inner());
/* 11 */         console.log(get_func_inner());
/* 12 */         console.log(get_func_inner());

function foo(outer_arg) { 

	function inner(inner_arg) { 
		return outer_arg + inner_arg; 
	} 
	return inner; 
} 
var get_func_inner = foo(5); 

console.log(get_func_inner(4)); 
console.log(get_func_inner(3)); 


// Outer function 
function outer() 
{ 
	function create_Closure(val) 
	{ 
		return function() 
		{ 
			return val; 
		} 
	} 
	var arr = []; 
	var i; 
	for (i = 0; i < 4; i++) 
	{ 
		arr[i] = create_Closure(i); 
	} 
	return arr; 
} 
var get_arr = outer(); 
console.log(get_arr[0]()); 
console.log(get_arr[1]()); 
console.log(get_arr[2]()); 
console.log(get_arr[3]()); 



