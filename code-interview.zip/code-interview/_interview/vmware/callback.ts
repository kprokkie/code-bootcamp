const callbackFn = (firstName, callback) => {
    setTimeout(() => {
        if (!firstName) return callback(new Error('no first name passed in!'))

        const fullName = `${firstName} Doe`

        return callback(fullName)
    }, 2000)
}

function test(data) {
    console.log(data + ' Kumar');
}

callbackFn('John', console.log);
callbackFn(null, console.log);
callbackFn('Pradeep', test)

const promiseFn = firstName => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (!firstName) reject(new Error('no first name passed in!'))

            const fullName = `${firstName} Doe`

            resolve(fullName)
        }, 2000)
    })
}

promiseFn('Jane').then(console.log)
promiseFn(null).catch(console.log)