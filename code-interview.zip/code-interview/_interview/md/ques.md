HTML5 related questions - DOCTYPE, semantic tags.
Few output based questions included promises.
Arrow functions and destructuring.
Closure.
isolated scope in directives.
directive vs component.
two way data binding.  

Find all possible interpretations of an array of digits, 
High Level Design for Doughnut chart, 
Some AngularJS questions about data-binding, directives., 
JavaScript Design patterns mainly Observer pattern  

Basic Problem Solving like Linked List related questions, 
Maximum Sum of a Sub Matrix, 
Basic JavaScript, 
Make Ext JS Ajax Call, 
angular js basics.  

Convert a list of dates to a specific format. 
Design google maps.
explain and how to avoid Memory leaks.

GFG
https://www.geeksforgeeks.org/vmware-interview-experience-set-13-staff-engineer-ui/

First round was telephonic, asked some basic javascript questions followed by below problem on hackerrank
– Find all the pairs of two integers in an unsorted array that sum up to a given S
- intersection point of two Linked Lists.
Difference between angular 1-2.
Different between recursive and iteration
find value in multi dimension array with O(logn)
Javascript Promises- example on race, all etc,, ES6 arrow function.
Some problem on callback array loop
HTTPClient, gave a code snippet on callback and told me to solve using promise.
some basic css questions
Binary tree algorithm problem on hackerrank platform
Gave a binary tree and told me to convert it to string without using JSON.stringify and convert it back to binary tree.

Given two balanced binary trees, tree A and tree B, determine if B is a subset of A. Tree A has a very large number of nodes (e.g., 1 million), and tree B has a much smaller amount of nodes (e.g., 1000).  





