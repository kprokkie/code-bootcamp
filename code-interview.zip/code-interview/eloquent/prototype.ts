// let empty = {};
// console.log(empty.toString);
// // → function toString(){…}
// console.log(empty.toString());
// // → [object Object]
// console.log(Object.getPrototypeOf({}) == Object.prototype);

let protoRabbit = {
    speak(line) {
        console.log(`The ${this.type} rabbit says '${line}'`);
    }
};
let killerRabbit = Object.create(protoRabbit);
killerRabbit.type = "killer";
killerRabbit.speak("SKREEEE!");
// → The killer rabbit says 'SKREEEE!'

function makeRabbit(type) {
    let rabbit = Object.create(protoRabbit);
    rabbit.type = type;
    return rabbit;
}

let mR = makeRabbit('weird new');
console.log(mR);
protoRabbit.speak.call(mR, 'Hello New');

function Rabbit(type) {
    this.type = type;
}
Rabbit.prototype.speak = function (line) {
    console.log(`The ${this.type} rabbit says '${line}'`);
};

let weirdRabbit = new Rabbit("weird");
weirdRabbit.speak('Hello');

console.log(Object.getPrototypeOf(Rabbit) == Function.prototype);
console.log(Object.getPrototypeOf(weirdRabbit) == Rabbit.prototype);

{
    class Rabbit {
        constructor(type) {
            this.type = type;
        }
        speak(line) {
            console.log(`The ${this.type} rabbit says '${line}'`);
        }
    }

    let killerRabbit = new Rabbit("killer");
    let blackRabbit = new Rabbit("black");

    killerRabbit.speak('wow');
    blackRabbit.speak('now');

    Rabbit.prototype.teeth = 'long';

    killerRabbit.teeth = 'small';
    console.log(killerRabbit.teeth);
    console.log(blackRabbit.teeth);

    let sym = Symbol("name");
    console.log(sym == Symbol("name"));
    // → false
    Rabbit.prototype[sym] = 55;
    console.log(blackRabbit[sym]);
    // → 55

}

{
    console.log(Array.prototype.toString == Object.prototype.toString);
    // → false
    console.log([1, 2].toString());
    // → 1,2

    let ages = {
        Boris: 39,
        Liang: 22,
        Júlia: 62
    };

    console.log(`Júlia is ${ages["Júlia"]}`);
    // → Júlia is 62
    console.log("Is Jack's age known?", "Jack" in ages);
    // → Is Jack's age known? false
    console.log("Is toString's age known?", "toString" in ages);
    // → Is toString's age known? true

    console.log("toString" in Object.create(null));
    // → false
}

{

    function Vehicle (type) {
        this.type =  type;
    }

    Vehicle.prototype.avg = 90;

    let car = new Vehicle('car');
    console.log(Object.getPrototypeOf(car));
    car.speed = 50;
    for (let p in car) {
        console.log(p);
    }

    let bus = new Vehicle('bus');

    console.log(Object.getPrototypeOf(bus));

    for (let p in bus) {
        console.log(p);
    }


}
