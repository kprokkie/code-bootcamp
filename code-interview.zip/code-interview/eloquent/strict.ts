{
    // function Person(name) {
    //     this.name = name;
    // }

    // let ferdinand = Person("Ferdinand"); // oops
    // console.log(name);
    // → Ferdinand

    // let ferdinand1 = new Person("Ferdinand"); // oops
    // console.log(name);
} 
{
    "use strict";
    function Person1(name) {
        this.name = name;
    }

    let ferdinand = Person1("Ferdinand"); // oops
    console.log(name);
    // → Ferdinand
}