{

    let a = 'foo.bar';
    let b = 'foo.baz.qux';

    function createObject(a, value) {
        let keys = a.split('.');
        let l = keys.length - 1;

        let obj = null;
        for (let i = l; i >= 0; i--) {
            let tempObj = {};
            tempObj[keys[i]] = obj || value;
            obj = tempObj;
        }
        return obj;
    }

    function createObjectR(a, value) {

        let keys = a.split('.');
        let idx = 0;

        function helper(key) {

            if (!key) return value;

            let obj = {};
            obj[key] = helper(keys[++idx]);
            return obj;
        }

        return helper(keys[idx]);
    }

    console.log(createObjectR(a, ''));
    console.log(createObjectR(b, ''));

    console.log(createObject(a, ''));
    console.log(createObject(b, ''));
}