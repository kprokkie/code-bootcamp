function reverseArray(a) {
    return a.reverse();
}

const arr = [2, 3, 4, 1];
console.log(reverseArray(arr));