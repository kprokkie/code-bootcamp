/**
 * Definition for a binary tree node.
 * function TreeNode(val) {
 *     this.val = val;
 *     this.left = this.right = null;
 * }
 */
/**
 * @param {TreeNode} root
 * @return {boolean}
 */

const root = {
    val: 10,
    left: { val: 5, left: null, right: null },
    right: {
        val: 15,
        left: { val: 6, left: null, right: null },
        right: { val: 20, left: null, right: null }
    }
};

var isValidBST = function (root) {
    return validateNode(root);
};

function validateNode(root) {
    if (!root) {
        return true;
    }
    let currentNode = root;
    return checkLeft(currentNode) && checkRight(currentNode);
}

function checkLeft(currentNode) {
    if (currentNode.left) {
        if (!(currentNode.val > currentNode.left.val)) {
            return false;
        } else {
            return validateNode(currentNode.left);
        }
    }
    return true;
}

function checkRight(currentNode) {
    if (currentNode.right) {
        if (!(currentNode.val < currentNode.right.val)) {
            return false;
        } else {
            return validateNode(currentNode.right);
        }
    }
    return true;
}

console.log(validateNode(root));

// var isValidBST = function(root) {
    
//     function helper(node) {
//         if (!node) return true;
        
//         let l = node.left ? node.left.val >= node.val ? false : helper(node.left) : true;
//         let r = node.right ? node.right.val <= node.val ? false : helper(node.right): true;
        
//         return l && r;
//     }
    
//     return helper(root);
    
// };
